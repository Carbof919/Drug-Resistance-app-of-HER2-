import streamlit as st
import pandas as pd
import pickle

# Title and instructions
st.set_page_config(page_title="HER2+ Drug Resistance Predictor")
st.title("💊 HER2+ Breast Cancer Drug Resistance Predictor")
st.markdown("Upload gene expression data to predict resistance to **Lapatinib**.")

# Load the model
@st.cache_resource
def load_model():
    with open("models/Lapatinib_model.pkl", "rb") as f:
        model = pickle.load(f)
    with open("models/features.pkl", "rb") as f:
        feature_names = pickle.load(f)
    return model, feature_names

model, feature_names = load_model()

# Upload input CSV
uploaded_file = st.file_uploader("📤 Upload gene expression CSV", type=["csv"])

if uploaded_file is not None:
    try:
        df = pd.read_csv(uploaded_file)

        # Show the uploaded data
        st.subheader("📊 Uploaded Data Preview")
        st.write(df.head())

        # Check for required columns
        missing = [gene for gene in feature_names if gene not in df.columns]
        if missing:
            st.error(f"❌ Missing required genes: {missing}")
        else:
            # Align columns
            X_input = df[feature_names]

            # Predict
            prediction = model.predict(X_input)
            st.success("✅ Prediction Complete!")

            # Show predictions
            df["Prediction"] = prediction
            st.subheader("📈 Prediction Output")
            st.write(df)

            # Download option
            csv = df.to_csv(index=False)
            st.download_button("📥 Download Prediction Results", data=csv, file_name="predictions.csv", mime="text/csv")

    except Exception as e:
        st.error(f"⚠️ Error: {str(e)}")
else:
    st.info("Please upload a CSV file with gene expression values.")
